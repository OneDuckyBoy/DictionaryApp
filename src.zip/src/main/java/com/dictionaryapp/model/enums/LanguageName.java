package com.dictionaryapp.model.enums;

public enum LanguageName {
    GERMAN, SPANISH, FRENCH, ITALIAN
}
